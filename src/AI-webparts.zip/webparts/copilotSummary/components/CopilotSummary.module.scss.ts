
require("./CopilotSummary.module.css");
const styles = {
  copilotSummary: 'copilotSummary_628554d4',
  teams: 'teams_628554d4',
  welcome: 'welcome_628554d4',
  welcomeImage: 'welcomeImage_628554d4',
  links: 'links_628554d4',
  chatBox: 'chatBox_628554d4',
  user: 'user_628554d4',
  assistant: 'assistant_628554d4',
  inputRow: 'inputRow_628554d4',
  wrapper: 'wrapper_628554d4',
  header: 'header_628554d4',
  title: 'title_628554d4',
  subtitle: 'subtitle_628554d4',
  card: 'card_628554d4',
  cardTitle: 'cardTitle_628554d4',
  fileInput: 'fileInput_628554d4',
  textarea: 'textarea_628554d4',
  primaryBtn: 'primaryBtn_628554d4',
  sendBtn: 'sendBtn_628554d4',
  message: 'message_628554d4',
  input: 'input_628554d4',
  loading: 'loading_628554d4',
  uploaded: 'uploaded_628554d4'
};

export default styles;
